import React from "react";
import { Row, Form, Col, Button } from "react-bootstrap";

class AddService extends React.Component {
  constructor(props) {
    super(props);

    this.initialState = {
      //userId: '',
      //id:'',
      reg_Email: "",
      reg_Password: "",
      reg_UserName: "",
      reg_MobileNumber: "",
      reg_CameraServiceName:"",
      reg_Price:"",
    };

    if (props.user.id) {
      this.state = props.user;
    } else {
      this.state = this.initialState;
    }

    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleChange(event) {
    const name = event.target.name;
    const value = event.target.value;

    this.setState({
      [name]: value,
    });
  }

  handleSubmit(event) {
    event.preventDefault();
    this.props.onFormSubmit(this.state);
    this.setState(this.initialState);
  }
  render() {
    let pageTitle;
    let actionStatus;
    if (this.state.id) {
      pageTitle = <h2>Edit Services</h2>;
      actionStatus = <b>Update</b>;
    } else {
      pageTitle = <h2>Add Services</h2>;
      actionStatus = <b>Save</b>;
    }

    return (
      <div>
        <h2> {pageTitle}</h2>
        <Row>
          <Col sm={7}>
            <Form onSubmit={this.handleSubmit}>
              <Form.Group controlId="reg_Email">
                <Form.Label>Email</Form.Label>
                <Form.Control
                  type="text"
                  name="reg_Email"
                  data-testid="email"
                  value={this.state.reg_Email}
                  onChange={this.handleChange}
                  placeholder="Email"
                />
              </Form.Group>
              <Form.Group controlId="reg_Password">
                <Form.Label>Password</Form.Label>
                <Form.Control
                  type="password"
                  name="reg_Password"
                  data-testid="password"
                  value={this.state.reg_Password}
                  onChange={this.handleChange}
                  placeholder="Password"
                />
              </Form.Group>
              <Form.Group controlId="reg_UserName">
                <Form.Label>UserName</Form.Label>
                <Form.Control
                  type="text"
                  name="reg_UserName"
                  data-testid="username"
                  value={this.state.reg_UserName}
                  onChange={this.handleChange}
                  placeholder="UserName"
                />
              </Form.Group>
              <Form.Group controlId="reg_MobileNumber">
                <Form.Label>MobileNumber</Form.Label>
                <Form.Control
                  type="text"
                  name="reg_MobileNumber"
                  data-testid="mobile"
                  value={this.state.reg_MobileNumber}
                  onChange={this.handleChange}
                  placeholder="MobileNumber"
                />
                </Form.Group>
                <Form.Group controlId="reg_CameraServiceName">
                <Form.Label>CameraServiceName</Form.Label>
                <Form.Control
                  type="text"
                  name="reg_CameraServiceName"
                  data-testid="camservname"
                  value={this.state.reg_CameraServiceName}
                  onChange={this.handleChange}
                  placeholder="CameraServiceName"
                />
                </Form.Group>        
                <Form.Group controlId="reg_Price">
                <Form.Label>Price</Form.Label>
                <Form.Control
                  type="text"
                  name="reg_Price"
                  data-testid="price"
                  value={this.state.reg_Price}
                  onChange={this.handleChange}
                  placeholder="Price"
                />
              </Form.Group>
              <Form.Group>
                <Form.Control
                  type="hidden"
                  name="id"
                  value={this.state.id}
                />
                <Button variant="success" type="submit">
                  {actionStatus}
                </Button>
              </Form.Group>
            </Form>
          </Col>
        </Row>
      </div>
    );
  }
}

export default AddService;