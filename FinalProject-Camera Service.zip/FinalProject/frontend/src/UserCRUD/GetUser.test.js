import React from "react";
import { render, screen } from "@testing-library/react";
import UserList from "./GetUser";
import axios from "axios";

const BASE_URL = "https://localhost:7152/Api/Camera";

jest.mock("axios");

describe("Add User Component", () => {
  const mockEditUser = jest.fn();

  it("Should have all columns in the header", () => {
    render(<UserList editServices={mockEditServices} />);
    expect(screen.getByText("Email")).toBeInTheDocument();
    expect(screen.getByText("Password")).toBeInTheDocument();
    expect(screen.getByText("UserName")).toBeInTheDocument();
    expect(screen.getByText("MobileNumber")).toBeInTheDocument();
    expect(screen.getByText("CameraServiceName")).toBeInTheDocument();
    expect(screen.getByText("Price")).toBeInTheDocument();
  });
  it("should return users list while loading", async () => {
    const users = [
      {
        id: 1,
        Email: "testemail",
        Password: "testpass",
        UserName: "testname",
        MobileNumber: "testmob",
        CameraServiceName:"testservice",
        Price:"testprice",
      },
      {
        id: 2,
        Email: "testemail2",
        Password: "testpass2",
        UserName: "testname2",
        MobileNumber: "testmob2",
        CameraServiceName:"testservice2",
        Price:"testprice2",
      },
     
    ];
    // Mocking the Axios.get to return the Users value
    axios.get = jest.fn();
    axios.get.mockResolvedValueOnce(users);

    // when
    render(<UserList editServices={mockEditServices} />);

    // then - verify that the get endpoint has been called
    expect(axios.get).toHaveBeenCalledWith(`${BASE_URL}/Cctvcam`);
  });
});