import React, { Component } from "react";
import { Container, Button } from "react-bootstrap";
import UserList from "./GetUser";
import AddService from "./AddService";
import axios from "axios";
import { Link } from 'react-router-dom';

const apiUrl = "https://localhost:7152/Api/Camera";

class UserActionApp extends Component {
  constructor(props) {
    super(props);

    this.state = {
      isAddService: false,
      error: null,
      response: {},
      userData: {},
      isEditServices: false,
      isCctvcams: true,
    };

    this.onFormSubmit = this.onFormSubmit.bind(this);
  }

  onCreate() {
    this.setState({ isAddService: true });
    this.setState({ isCctvcams: false });
  } 
  onDetails() {
    this.setState({ isCctvcams: true });
    this.setState({ isAddService: false });
  }

  onFormSubmit(data) {
    this.setState({ isAddService: true });
    this.setState({ isCctvcams: false });
    if (this.state.isEditServices) {
      axios.put(apiUrl + "/UpdateServiceDetails", data).then((result) => {
        alert(result.data);
        this.setState({
          response: result,
          isAddService: false,
          isEditServices: false,
        });
      });
    } else {
      axios.post(apiUrl + "/Insertmethod", data).then((result) => {
        alert(result.data);
        this.setState({
          response: result,
          isAddService: false,
          isEditServices: false,
        });
      });
    }
  }

  isEditServices = (id) => {
    this.setState({ isCctvcams: false });
    axios.get(apiUrl + "/Cctvcam" + id).then(
      (result) => {
        this.setState({
          isEditServices: true,
          isAddService: true,
          userData: result.data,
        });
      },
      (error) => {
        this.setState({ error });
      }
    );
  };

  render() {
    let userForm;
    if (this.state.isAddService || this.state.isEditServices) {
      userForm = (
        <AddService
          data-testid="addservice"
          onFormSubmit={this.onFormSubmit}
          user={this.state.userData}
        />
      );
    }
    return (
      <div className="App">

      <button className="logbtn"><Link  to="/" className="logbtn">logout</Link></button>

        <Container>
          <h1 style={{ textAlign: "center" }}>Camera Services</h1>
          <hr></hr>
          {!this.state.isCctvcams && (
            <Button variant="primary" onClick={() => this.onDetails()}>
              {" "}
              Service Details
            </Button>
          )}
          {!this.state.isAddService && (
            <Button variant="primary" onClick={() => this.onCreate()}>
              Add Service
            </Button>
          )}
          <br></br>
          {!this.state.isAddService && (
            <UserList data-testid="userlist" editServices={this.editServices} />
          )}
          {userForm}
        </Container>
      </div>
    );
  }
}
export default UserActionApp;