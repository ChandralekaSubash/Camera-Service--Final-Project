import React from "react";
import { render } from "@testing-library/react";
import AddService from "./AddService";

describe("Add User Component", () => {
  const mockFormSubmit = jest.fn();
  const stubbedUserData = {
    id: "",
    Email: "",
    Password: "",
    UserName: "",
    MobileNumber: "",
    CameraServiceName:"",
    Price:"",
  };

  it("Show all input fields with empty value", () => {
    const { getByTestId } = render(
      <AddService onFormSubmit={mockFormSubmit} user={stubbedUserData} />
    );

    expect(getByTestId("Email").value).toBe("");
    expect(getByTestId("Password").value).toBe("");
    expect(getByTestId("UserName").value).toBe("");
    expect(getByTestId("MobileNumber").value).toBe("");
    expect(getByTestId("CameraServiceName").value).toBe("");
    expect(getByTestId("Price").value).toBe("");
  });
});