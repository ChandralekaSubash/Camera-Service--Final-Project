import './App.css';
//import Login from './UserCRUD/Login';
import UserActionApp from './UserCRUD/UserActions';
import Login from './UserCRUD/Login';
import {Routes,Route} from 'react-router-dom';
function App() {
  return (
    <>
    <Routes>
     <Route path='/Login' element={<UserActionApp/>} />
     <Route path='/' element={<Login/>} />
     </Routes>
     </>
  );
}

export default App;
