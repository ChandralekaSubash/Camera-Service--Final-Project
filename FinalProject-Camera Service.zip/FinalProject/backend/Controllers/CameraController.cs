using Microsoft.AspNetCore.Mvc;
using backend.Models;

namespace backend.Controllers;

[ApiController]
[Route("Api/Camera")]
public class CameraController : ControllerBase
{
    private readonly  CameradbContext db;

    public CameraController(CameradbContext ds)
    {
        this.db=ds;
    }
    [HttpPost("Insertmethod")]

    public object Insertmethod(Register readobj)
    {
        string message="";
        try{
            Cctvcam cam =new Cctvcam();
            if(cam.Id==0)
            {
                cam.Email=readobj.Reg_Email;
                cam.Password=readobj.Reg_Password;
                cam.UserName=readobj.Reg_UserName;
                cam.MobileNumber=readobj.Reg_MobileNumber;
                cam.CameraServiceName=readobj.Reg_CameraServiceName;
                cam.Price=readobj.Reg_Price;
                db.Cctvcams.Add(cam);
               
              
                    int result = this.db.SaveChanges();
                    if (result > 0)
                    {
                        message = "User has been sucessfully added";
                    }
                    else
                    {
                        message = "failed";
                    }

                     return Ok(message);
            //Add

            //save it in the database
            db.SaveChanges();

            return new Response{Status="Success" , Message = "Employee Added!"};

        }
    }
    catch(System.Exception)
    {
throw;
    }

    return new Response{Status="Error" , Message="Invalid Information"};
  }
    [HttpPost("Logins")]

    public IActionResult loginchk(Logins chk)
    {

        var logindetail=db.Cctvcams.Where(i=>i.Email.Equals(chk.Email)&& i.Password.Equals(chk.Password)).FirstOrDefault();

        if(logindetail==null)
        {
            return Ok(new Response{Status="Invalid user",Message="Invalid Credential"});
        }
        else
        {
            return Ok(new Response{Status="Valid User",Message="Success"});
        }

    }
    [HttpGet("viewdetail")]

    public IQueryable<Cctvcam>getCctv()
    {
        try{
            return db.Cctvcams;
        }
        catch(SystemException)
        {
            throw;
        }

    }
    [HttpDelete("DeleteUserDetails/{Id}")]
    public IActionResult DeleteService(int id)
    {
        string message = "";
            var user = this.db.Cctvcams.Find(id);
            if (user == null)
            {
                return NotFound();
            }

            this.db.Cctvcams.Remove(user);
            int result = this.db.SaveChanges();
            if (result > 0)
            {
                message = "Services has been successfully deleted";
            }
            else
            {
                message = "failed";
            }

            return Ok(message);
        }
   
}