public class Register
{
    public int Id { get; set; }

    public string Reg_Email { get; set; }

    public string Reg_Password { get; set; }

    public string Reg_UserName { get; set; }

    public string Reg_MobileNumber { get; set; }
    public string Reg_CameraServiceName { get; set; }

    public string Reg_Price { get; set; }
}